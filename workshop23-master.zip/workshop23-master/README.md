# React Workshop
Welcome to the workshop. Just run:

```sh
npm install
npm start
```

Visit `http://localhost:3000` and you should see `You're all set for the workshop!`. That's it for the setup!
