import React from 'react';
import ReactDOM from 'react-dom';
import Todos from './todos'

ReactDOM.render(<Todos />, 
            document.getElementById('root'));